from flask import Flask, request, make_response, redirect, url_for, render_template_string

app = Flask(__name__)

@app.route('/')
def index():
    return f'Zmień motyw na ciemny bądź jasny'

@app.route('/dashboard')
def dashboard():
    theme = request.args.get('theme')
    if theme in ['dark', 'light']:
        resp = make_response(redirect(url_for('show_theme'))) #ustawianie ciasteczka
        resp.set_cookie('theme', theme, max_age=1*1*20)
        return resp
    else:
        return "Invalid theme"
    
@app.route('/index')
def show_theme():
    theme = request.cookies.get('theme', 'light')  # dodczytanie ciasteczka (domyślnie motyw jasny)
    html_content = """
    <!doctype html>
    <html lang="en">
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Theme Example</title>
        <style>
          body {{
            background-color: {};
            color: {};
          }}
        </style>
      </head>
      <body>
        <h1>Theme set to: {}</h1>
        <a href="/dashboard?theme=dark">Set Dark Theme</a>
        <a href="/dashboard?theme=light">Set Light Theme</a>
      </body>
    </html>
    """.format('#333' if theme == 'dark' else '#fff', '#fff' if theme == 'dark' else '#000', theme)
    return render_template_string(html_content)

@app.route('/delete_cookie')
def delete_cookie():
    resp = make_response(redirect(url_for('show_theme')))
    resp.delete_cookie('theme')
    return resp

if __name__ == '__main__':
    app.run(debug=True)
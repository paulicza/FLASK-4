from flask import Flask, request, make_response, redirect, url_for, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return f'Zmień motyw na ciemny bądź jasny'

@app.route('/dashboard')
def dashboard():
    theme = request.args.get('theme')
    if theme in ['dark', 'light']:
        resp = make_response(redirect(url_for('show_theme'))) #ustawianie ciasteczka
        resp.set_cookie('theme', theme, max_age=1*1*20)
        return resp
    else:
        return "Invalid theme"
    
@app.route('/index')
def show_theme():
    theme = request.cookies.get('theme', 'light')  # dodczytanie ciasteczka (domyślnie motyw jasny)
    return render_template('index.html', theme=theme)

if __name__ == '__main__':
    app.run(debug=True)
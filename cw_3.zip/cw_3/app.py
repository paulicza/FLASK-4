from flask import Flask, request, make_response, url_for, redirect

app = Flask(__name__)

@app.route('/')
def start():
    return 'Welcome to the Dashboard!'

@app.route('/dashboard')
def dashboard():
    theme = request.args.get('theme')
    if theme == 'dark':
        # Ustawienie ciasteczka na motyw ciemny ważne przez 6 godzin
        resp = make_response(redirect(url_for('show_theme')))
        resp.set_cookie('theme', 'dark', max_age=10*1*1)
        return resp
    elif theme == 'light':
        # Ustawienie ciasteczka na motyw jasny ważne przez 6 godzin
        resp = make_response(redirect(url_for('index')))
        resp.set_cookie('theme', 'light', max_age=60*60*6)
        return resp
    else:
        return "Invalid theme"

@app.route('/index')
def show_theme():
    theme = request.cookies.get('theme')
    if theme:
        return f'Theme set to: {theme}'
    else:
        return 'Theme not set'
    
# @app.route('/delete_cookie')
# def delete_cookie():
#     resp = make_response(redirect(url_for('show_theme')))
#     resp.delete_cookie('username')
#     return resp

if __name__ == '__main__':
    app.run(debug=True)
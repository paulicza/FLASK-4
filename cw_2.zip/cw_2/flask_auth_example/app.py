from flask import Flask, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from forms import LoginForm, RegisterForm
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import timedelta
#OBSŁUGA UPRAWNIEŃ WE FLASKU:
from functools import wraps
from flask import abort
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24) 
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=2)  # Czas trwania sesji
db = SQLAlchemy(app)
login_manager = LoginManager() #implementuje moduł logowania 
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False, default = 'user')


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data, method='pbkdf2')
        new_user = User(username=form.username.data, password=hashed_password, role=form.role.data) #OBSLUGA UPRAWNIENI WE FLASKU (ROLE)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            return redirect(url_for('dashboard'))
        flash('Invalid username or password')
    return render_template('login.html', form=form)

@app.route('/dashboard')
@login_required
def dashboard():
    return f'Hello, {current_user.username}!'

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

def role_required(role): #wymagana rola użytkownika
    def decorator(func): #funkcja dekorator przymuje funkcje func ktora chcemy chronic
        @wraps(func) #mateadane oryginalnej funkcji są zachowane
        def decorated_view(*args, **kwargs): #funckja dekorator zawija dunkcje endpointu w decrator_view
            if not current_user.is_authenticated or current_user.role != role: #czy uzytkownik jest uwierzetelniony i czy rola jest zgodna z wymagana rolą przekazana do dekoratora role
                abort(403) #jesli nie to bład
            return func(*args, **kwargs) #jesli tak to wywoływana oryginalna funkcja func i przrkazywane są do niej wszytskie argumenty i sowa kluczowe 
        return decorated_view
    return decorator

@app.route('/admin')
@login_required
@role_required('admin')
def admin():
    return f'Hello Admin {current_user.username}!'



@app.route('/user')
@login_required
@role_required('user')
def user_dashboard():
    return f'Hello User {current_user.username}!'



if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)